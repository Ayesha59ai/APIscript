package SpecBuilder_1;

import org.hamcrest.Matchers;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Spec_builder_generic 
{
	@BeforeMethod
	public RequestSpecification request(String url,String body, String contenttype) 
	{
		RequestSpecBuilder s=new RequestSpecBuilder();
		RequestSpecification req = s.setBaseUri(url).setBody(body).setContentType(contenttype).build();
		return req;
		
	}
	@AfterMethod
	public ResponseSpecification response(int code, String statusline,long time) {
		ResponseSpecBuilder s=new ResponseSpecBuilder();
		ResponseSpecification rep = s.expectStatusCode(code).expectStatusLine(statusline).
		expectResponseTime(Matchers.lessThanOrEqualTo(time)).build();
		return rep; 
	}
	//get
	@BeforeMethod
	public RequestSpecification requestget(String url) 
	{
		RequestSpecBuilder s=new RequestSpecBuilder();
		RequestSpecification req = s.setBaseUri(url).build();
		return req;
		
	}

}
