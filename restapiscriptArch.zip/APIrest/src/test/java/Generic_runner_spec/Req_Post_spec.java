package Generic_runner_spec;

import java.io.IOException;

import org.testng.annotations.Test;

import Property.Get_Property;
import SpecBuilder_1.Spec_builder_generic;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Req_Post_spec 
{
	@Test
	public void Postcreate() throws IOException 
	{
		//pass url and endpoit as a var
		Get_Property gp=new Get_Property();
		String url = gp.getdata("url");
		String endpoint = gp.getdata("postendpoint");
		
		Spec_builder_generic s=new Spec_builder_generic();
		//pass var for url
		RequestSpecification req = s.request(url, "{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}", "application/json");
		ResponseSpecification res = s.response(201, "HTTP/1.1 201 Created", 5000);
		
		Response respo = RestAssured.given().spec(req).when().post(endpoint).then().spec(res).extract().response();
		System.out.println(respo.asPrettyString());
	}
	//get
	@Test
	public void getuser() throws IOException {
		Get_Property gp=new Get_Property();
		String url = gp.getdata("url");
		String endpoint = gp.getdata("getendpoint");
		
		Spec_builder_generic s=new Spec_builder_generic();
		RequestSpecification reqe = s.requestget(url);
		ResponseSpecification respo = s.response(200, "HTTP/1.1 200 OK", 4000);
		
		Response response = RestAssured.given().spec(reqe).
				when().get(endpoint).then().spec(respo).extract().response();
		System.out.println(response.asPrettyString());
		
	}
	//patch
	@Test
	public void updateuser() throws IOException 
	{
		Get_Property gp=new Get_Property();
		String url = gp.getdata("url");
		String endpoint = gp.getdata("patchendpoint");
		
		Spec_builder_generic s=new Spec_builder_generic();
		RequestSpecification req = s.request(url, "{\r\n"
				+ "    \"name\": \"aahddpbnheus\",\r\n"
				+ "    \"job\": \"zion resident\"\r\n"
				+ "}", "application/json");
		ResponseSpecification resp = s.response(200, "HTTP/1.1 200 OK", 8000);
		
	Response response = RestAssured.given().spec(req).when().patch(endpoint).then().spec(resp).extract().response();
	System.out.println(response.asPrettyString());
	}
	@Test
	public void put() throws IOException 
	{
		Get_Property gp=new Get_Property();
		String url = gp.getdata("url");
		String endpoint = gp.getdata("patchendpoint");
		Spec_builder_generic s=new Spec_builder_generic();
		RequestSpecification req = s.request(url, "{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"zion resident\"\r\n"
				+ "}", "application/json");
		ResponseSpecification resp = s.response(200, "HTTP/1.1 200 OK", 5000);
		
		Response response = RestAssured.given().spec(req).
				when().put(endpoint).then().spec(resp).extract().response();
		System.out.println(response.asPrettyString());
		
	}
	@Test
	public void Delete() throws IOException 
	{
		Get_Property gp=new Get_Property();
		String url = gp.getdata("url");
		String endpoint = gp.getdata("deleteendpoint");
		Spec_builder_generic s=new Spec_builder_generic();
		RequestSpecification req = s.requestget(url);
		ResponseSpecification rep = s.response(204, "HTTP/1.1 204 No Content", 5000);
		
		Response resp = RestAssured.given().spec(req).
				when().delete(endpoint).then().spec(rep).extract().response();
		System.out.println(resp.asPrettyString());
	}
}