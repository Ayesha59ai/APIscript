package Property;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class Get_Property 
{
	@Test
	public String getdata(String key) throws IOException 
	{
		//path specify
		//to get the location of the file
		FileInputStream fis=new FileInputStream("./Property/data.properties");
		//class to fetch data and access get
		Properties p=new Properties(); 
		p.load(fis);
		//if i have multiple data inside my property i hva to create multiple getpropty so we r using method with param
		String url = p.getProperty(key);
		return url;
		
	//	System.out.println(url);
		//String endpoint = p.getProperty(key);
	//	System.out.println(endpoint);
		//String getendp = p.getProperty("getendpoint");
		//System.out.println(getendp);
		
	}

}
