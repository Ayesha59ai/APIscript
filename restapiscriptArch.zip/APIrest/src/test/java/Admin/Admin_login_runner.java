package Admin;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Admin_login_runner 
{
	public String userid;
	public String token;
	@Test(priority=1)
	public void login() throws JsonProcessingException 
	{
		Pojo_Admin ad = new Pojo_Admin();
		ad.setEmail("ayesha7654@gmail.com");
		ad.setPassword("Ayesha@123");
		ad.setRole("ADMIN");
		
	ObjectMapper obj=new ObjectMapper();
	String jsonbody = obj.writeValueAsString(ad);
	
	Response respon = RestAssured.given().relaxedHTTPSValidation().body(jsonbody).
			contentType("application/json").
	when().post("https://www.shoppersstack.com/shopping/users/login").
	then().statusCode(200).extract().response();
	System.out.println(respon.asPrettyString());
	JsonPath jp = new JsonPath(respon.asPrettyString());
	 userid = jp.getString("data.userId");
	System.out.println(userid);
	token=jp.getString("data.jwtToken");

}
	@Test(priority=2)
	public void getdata() 
	{
		Response res = RestAssured.
				given().relaxedHTTPSValidation().pathParam("adminId", userid).
				auth().oauth2(token).
		when().get("https://www.shoppersstack.com/shopping/admin/{adminId}").
		then().statusCode(200).extract().response();
		System.out.println(res.asPrettyString());
		
	}
}