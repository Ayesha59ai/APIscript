package Admin;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Admin_runner 
{
	@Test
	public void createadmin() throws JsonProcessingException {
		/*
		 * Pojo_serelization_Admin pj = new Pojo_serelization_Admin();
		 * pj.setCity("Bangalore"); pj.setCountry("India");
		 * pj.setEmail("ayeshafathimaaa45@gmail.com"); pj.setFirstName("Ayeshafa");
		 * pj.setGender("FEMALE"); pj.setImageId("String"); pj.setJwtToken("String");
		 * pj.setLastName("fathimaa"); pj.setPassword("Ayeshaf@244");
		 * pj.setPhone("9789257283"); pj.setRole("ADMIN"); pj.setState("Karnataka");
		 * pj.setStatus("Active"); pj.setToken("String"); pj.setZoneId("String");
		 * 
		 * ObjectMapper obj = new ObjectMapper(); String jsonbody =
		 * obj.writerWithDefaultPrettyPrinter().writeValueAsString(pj);
		 * System.out.println(jsonbody);
		 */    
  Response respon = RestAssured.
		  given().relaxedHTTPSValidation().
		  body("{\r\n"
		  		+ "  \"city\": \"Bangalore\",\r\n"
		  		+ "  \"country\": \"India\",\r\n"
		  		+ "  \"createdDateTime\": \"2025-03-21T11:59:09.328Z\",\r\n"
		  		+ "  \"dob\": \"2000-05-09\",\r\n"
		  		+ "  \"email\": \"ayesha7654@gmail.com\",\r\n"
		  		+ "  \"firstName\": \"ayesha\",\r\n"
		  		+ "  \"gender\": \"FEMALE\",\r\n"
		  		+ "  \"imageId\": \"string\",\r\n"
		  		+ "  \"jwtToken\": \"string\",\r\n"
		  		+ "  \"lastName\": \"Fathima\",\r\n"
		  		+ "  \"password\": \"Ayesha@123\",\r\n"
		  		+ "  \"phone\": \"9876543210\",\r\n"
		  		+ "  \"role\": \"ADMIN\",\r\n"
		  		+ "  \"state\": \"Karnataka\",\r\n"
		  		+ "  \"status\": \"ACTIVE\",\r\n"
		  		+ "  \"token\": \"string\",\r\n"
		  		+ "  \"zoneId\": \"string\"\r\n"
		  		+ "}").contentType("application/json").
		  when().post("https://www.shoppersstack.com/shopping/admin").
    then().statusCode(201).and().statusLine("HTTP/1.1 201 ").extract().response();
  System.out.println(respon.asPrettyString());
   
    
   
    

	}

}
