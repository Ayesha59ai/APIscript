package HybridFramework;

import java.io.IOException;

import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import Property.Get_Property;
import SpecBuilder_1.Spec_builder_generic;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Shopper_login_runner 
{
	@Test
	public void Login() throws IOException 
	{
		Login_pojo lp = new Login_pojo ();
		lp.setEmail("ayeshafath7854@gmail.com");
		lp.setPassword("Ayesha@45673");
		lp.setRole("SHOPPER");
		
		ObjectMapper obj=new ObjectMapper();
		String jsonbody = obj.writeValueAsString(lp);
		
		Get_Property gp=new Get_Property();
		String url = gp.getdata("shopbaseurl");
		String content = gp.getdata("contenttype");
		String endpoint = gp.getdata("shopperloginendpoint");
		
		Spec_builder_generic specbuil=new Spec_builder_generic();
		RequestSpecification req = specbuil.request(url, jsonbody, content);
		ResponseSpecification res = specbuil.response(200, "HTTP/1.1 200 ", 3000l);
		
		RestAssured.given().relaxedHTTPSValidation().spec(req).when().post(endpoint).then().spec(res).log().all();
	}

}
