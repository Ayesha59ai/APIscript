package HybridFramework;

import java.io.IOException;

import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import POJO.ShopperPojo;
import Property.Get_Property;
import SpecBuilder_1.Spec_builder_generic;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Shopper_register_runner 
{
	@Test
	public void post() throws IOException 
	{
		ShopperPojo sp = new ShopperPojo();
		sp.setCity("Bangalore");
		sp.setCountry("India");
		sp.setEmail("ayeshafath7854@gmail.com");
		sp.setFirstName("Ayeshaf");
		sp.setGender("FEMALE");
		sp.setLastName("fathima");
		sp.setPassword("Ayesha@45673");
		sp.setPhone(6746872184l);
		sp.setState("Karnataka");
		sp.setZoneId("ALPHA");
		ObjectMapper obj=new ObjectMapper();
		String jsonbody = obj.writeValueAsString(sp);
		
		Get_Property gp=new Get_Property();
		String url = gp.getdata("shopbaseurl");
		String endpoint = gp.getdata("shoperregisterendpoint");
		String content = gp.getdata("contenttype");
	
		
		 Spec_builder_generic specbuil=new Spec_builder_generic();
		 RequestSpecification req = specbuil.request(url, jsonbody, content);
		ResponseSpecification res = specbuil.response(201, "HTTP/1.1 201 ", 3000l);
		RestAssured.given().relaxedHTTPSValidation().spec(req).when().post(endpoint).then().spec(res).log().all();
		
	}

}
