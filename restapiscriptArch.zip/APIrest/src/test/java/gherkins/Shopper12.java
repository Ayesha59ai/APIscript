package gherkins;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Shopper12 
{
	//json parsing
	public String email;
	public int userid;
	public String token;
	@Test(priority=1)
	public void create() {
		String random = RandomStringUtils.randomAlphanumeric(5);
		String raemail = "Ayesha"+random+"@gmail.com";
		
		Response response = RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
				+ "  \"city\": \"Bangalore\",\r\n"
				+ "  \"country\": \"India\",\r\n"
				+ "  \"email\": \""+raemail+"\",\r\n"
				+ "  \"firstName\": \"Ayesha12\",\r\n"
				+ "  \"gender\": \"FEMALE\",\r\n"
				+ "  \"lastName\": \"fathi59\",\r\n"
				+ "  \"password\": \"Ayesha@123fathi\",\r\n"
				+ "  \"phone\": 6379456372,\r\n"
				+ "  \"state\": \"Karnata\",\r\n"
				+ "  \"zoneId\": \"ALPHA\"\r\n"
				+ "}").contentType("application/json").
		when().post(" https://www.shoppersstack.com/shopping/shoppers").
		then().statusCode(201).extract().response();
		
		 
		JsonPath jp=new JsonPath(response.asPrettyString());
		 email = jp.getString("data.email");
		System.out.println(email);
		
	}
	@Test(priority=2)
	public void shopperlogin() 
	{
		Response resp = RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
				+ "  \"email\": \""+email+"\",\r\n"
				+ "  \"password\": \"Ayesha@123fathi\",\r\n"
				+ "  \"role\": \"SHOPPER\"\r\n"
				+ "}").contentType("application/json").
		when().post("https://www.shoppersstack.com/shopping/users/login").
		then().statusCode(200).extract().response();
		
		JsonPath jp =new JsonPath(resp.asPrettyString());
		userid = jp.getInt("data.userId");
		System.out.println(userid);
		token=jp.getString("data.jwtToken");
		}
	
	@Test(priority=3)
	public void findshopperid() {
		RestAssured.given().relaxedHTTPSValidation().pathParam("shopperId", userid).auth().oauth2(token).
		when().get("https://www.shoppersstack.com/shopping/shoppers/{shopperId}").
		then().statusCode(200).log().all();
	}

}
