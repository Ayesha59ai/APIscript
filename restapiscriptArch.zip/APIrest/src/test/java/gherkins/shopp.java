package gherkins;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class shopp {

		public String	 randomemail;
		
		public String email;
		public int userId;
		public String token;
		
		@Test(priority = 1)
		public void register() {
			//generate random email
		String alphanumeric = RandomStringUtils.randomAlphanumeric(4);
		randomemail = "Ayesha"+alphanumeric+"@gmail.com";
		System.out.println(randomemail);
		
		Response resp = RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
					+ "  \"city\": \"Bangalore\",\r\n"
					+ "  \"country\": \"India\",\r\n"
					+ "  \"email\": \""+ randomemail +"\",\r\n"
					+ "  \"firstName\": \"Ayesha12\",\r\n"
					+ "  \"gender\": \"FEMALE\",\r\n"
					+ "  \"lastName\": \"fathi59\",\r\n"
					+ "  \"password\": \"Ayesha@123fathi\",\r\n"
					+ "  \"phone\": 6379456372,\r\n"
					+ "  \"state\": \"Karnata\",\r\n"
					+ "  \"zoneId\": \"ALPHA\"\r\n"
					+ "}").contentType("application/json").
			when().post("https://www.shoppersstack.com/shopping/shoppers").
			then().statusCode(201).extract().response();//json parsing
		
		
		System.out.println(resp.asPrettyString());//reponse body
		System.out.println( resp.statusCode());
		JsonPath jp = new JsonPath(resp.asPrettyString());
		String mess = jp.getString("message");
		System.out.println(mess);//message
		
		email = jp.getString("data.email");
		System.out.println(email);//json parsing email
		}
		
		@Test(priority = 2)
		public void shopperlogin() {
			Response respon = RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
					+ "  \"email\": \""+ email+"\",\r\n"
					+ "  \"password\": \"Ayesha@123fathi\",\r\n"
					+ "  \"role\": \"SHOPPER\"\r\n"
					+ "}").contentType("application/json").
		when().post("https://www.shoppersstack.com/shopping/users/login").
		then().statusCode(200).extract().response();
			JsonPath jp = new JsonPath(respon.asPrettyString());
			userId = jp.getInt("data.userId");
			System.out.println(userId);
			token=jp.getString("data.jwtToken");
			System.out.println(token);
		}
		
		@Test(priority = 3)
		public void findshopperid() {
			RestAssured.given().relaxedHTTPSValidation(). pathParam("shopperId", userId).auth().oauth2(token).
			when().get("https://www.shoppersstack.com/shopping/shoppers/{shopperId}").
			then().statusCode(200).log().all();
		}

}
