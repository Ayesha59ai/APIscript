package gherkins;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Github {
	@Test
	public void CreateRepo() {
		RestAssured.given().auth().oauth2("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").
		body("{\r\n"
				+ "    \"name\":\"Restapigitaye\",\r\n"
				+ "    \"description\":\"testing rest apis\",\r\n"
				+ "    \"private\":false\r\n"
				+ "}").contentType("application/json").
		when().post("https://api.github.com/user/repos").
		then().statusCode(201).log().all();
	}
	@Test
	public void getrepo() 
	{
		RestAssured.given().auth().oauth2("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").
		pathParams("owner", "Ayesha59ai","repo","Restapigitaye").
		when().get("https://api.github.com/repos/{owner}/{repo}").then().statusCode(200).log().all();
	}
	@Test
	public void updaterepo() {
		RestAssured.given().auth().oauth2("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").
		pathParams("owner","Ayesha59ai","repo","Restapigitaye").
		body("{\r\n"
				+ "    \"name\":\"Restapigitaye12\",\r\n"
				+ "    \"description\":\"testing rest apis\",\r\n"
				+ "    \"private\":false\r\n"
				+ "}").contentType("application/json").
		when().patch("https://api.github.com/repos/{owner}/{repo}").
		then().statusCode(200).log().all();
	}
	@Test
	public void deleterepo() {
		RestAssured.given().auth().oauth2("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").
		pathParams("owner","Ayesha59ai","repo","Restapigitaye").
		when().delete("https://api.github.com/repos/{owner}/{repo}").then().statusCode(204).log().all();
		System.out.println("hjklk");
	}

}
