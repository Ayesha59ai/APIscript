package gherkins;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Restfullbooker {
	@Test
	public void create() {
		RestAssured.given().body("{\r\n"
				+ "    \"firstname\" : \"Jimaye\",\r\n"
				+ "    \"lastname\" : \"Brown\",\r\n"
				+ "    \"totalprice\" : 111,\r\n"
				+ "    \"depositpaid\" : true,\r\n"
				+ "    \"bookingdates\" : {\r\n"
				+ "        \"checkin\" : \"2018-01-01\",\r\n"
				+ "        \"checkout\" : \"2019-01-01\"\r\n"
				+ "    },\r\n"
				+ "    \"additionalneeds\" : \"Breakfast\"\r\n"
				+ "}").contentType("application/json").
		when().post("https://restful-booker.herokuapp.com/booking").then().
		statusCode(200).and().statusLine("HTTP/1.1 200 OK").and().header("Server", Matchers.equalTo("Cowboy")).
		and().body("booking.firstname", Matchers.equalTo("Jimaye")).
	
		log().all();
	}
	@Test
	public void getbooking() {
		RestAssured.given().
		when().get("https://restful-booker.herokuapp.com/booking/15597").
		then().statusCode(200).log().all();
	}
	@Test
	public void updatebooking() {
		RestAssured.given().pathParam("id", "2840") .auth().preemptive().basic("admin", "password123").
		body("{\r\n"
				+ "    \"firstname\" : \"Ayefathmmiii\",\r\n"
				+ "    \"lastname\" : \"Brown\",\r\n"
				+ "    \"totalprice\" : 111,\r\n"
				+ "    \"depositpaid\" : true,\r\n"
				+ "    \"bookingdates\" : {\r\n"
				+ "        \"checkin\" : \"2018-01-01\",\r\n"
				+ "        \"checkout\" : \"2019-01-01\"\r\n"
				+ "    },\r\n"
				+ "    \"additionalneeds\" : \"Breakfast\"\r\n"
				+ "}").contentType("application/json").
		when().put("https://restful-booker.herokuapp.com/booking/{id}").
		then().statusCode(200).log().all();
	}
	
	@Test
	public void partialupdatebooking() {
		RestAssured.given().pathParam("id", "4658").auth().basic("admin", "password123").
		body("{\r\n"
				+ "    \"firstname\" : \"ayes\",\r\n"
				+ "    \"lastname\" : \"fath\"\r\n"
				+ "}").contentType("application/json").
		when().patch("https://restful-booker.herokuapp.com/booking/{id}").
		then().statusCode(200).log().all();
	}
@Test
public void Deletebooking() {
	RestAssured.given().auth().basic("admin", "password123").
	when().delete("https://restful-booker.herokuapp.com/booking/4658").then().statusCode(200).log().all();
}
}
