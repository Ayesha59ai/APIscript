package gherkins;

import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Reqres {
	
	@Test
	public void post() {
		
		RestAssured.given().body("{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}").contentType("application/json").
		when().post("https://reqres.in/api/users").
		then().assertThat().
		statusCode(201).and().
		statusLine("HTTP/1.1 201 Created").and().
		time(Matchers.lessThanOrEqualTo(5000l)).
		and().
		body("name", Matchers.equalTo("morpheus")).and().
		header("Server", Matchers.equalTo("cloudflare")).log().all();
	}
	@Test	
	public void get() {
		
		Response response = RestAssured.when().get("https://reqres.in/api/users/2").
		then().extract().response();
		JsonPath jp = new JsonPath(response.asPrettyString());
		String ln = jp.getString("data.last_name");
		System.out.println(ln);
		
	int id = jp.getInt("data.id");
	System.out.println(id);
	
	String txt = jp.getString("support.text");
	System.out.println(txt);
	
	
	}
	@Test
	public void put() {
		RestAssured.given().body("{\r\n"
				+ "    \"name\": \"ayesha\",\r\n"
				+ "    \"job\": \"zion resident\"\r\n"
				+ "}").contentType("application/json").
		when().put("https://reqres.in/api/users/2").
		then().assertThat().statusCode(200).log().all();
	}
	@Test
	 public void patch() {
		 RestAssured.given().body("{\r\n"
		 		+ "    \"name\": \"morpheus\",\r\n"
		 		+ "    \"job\": \"zion resident\"\r\n"
		 		+ "}").when().patch("https://reqres.in/api/users/2").then().assertThat().statusCode(200).log().all();
	 }
	 @Test
	 public void delete() {
		 RestAssured.when().delete("https://reqres.in/api/users/2").
		 then().assertThat().statusCode(204).log().all();
	 }
	 
	 @Test
	 
	public void listuser() {
		
		 Response respon = RestAssured.given().when().get("https://reqres.in/api/users?page=2").
		 then().extract().response();
		 JsonPath jp = new JsonPath(respon.asPrettyString());
		 String ln = jp.getString("data[1].last_name");
		 System.out.println(ln);
	 }

}
