package gherkins;

import org.apache.commons.lang3.RandomStringUtils;
import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Shopperstack {
	public String	 randomemail;
	
	public String email;
	
	@Test
	public void register() {
		//generate random email
	String alphanumeric = RandomStringUtils.randomAlphanumeric(4);
	randomemail = "Ayesha"+alphanumeric+"@gmail.com";
	System.out.println(randomemail);
	
	Response resp = RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
				+ "  \"city\": \"Bangalore\",\r\n"
				+ "  \"country\": \"India\",\r\n"
				+ "  \"email\": \""+ randomemail +"\",\r\n"
				+ "  \"firstName\": \"Ayesha12\",\r\n"
				+ "  \"gender\": \"FEMALE\",\r\n"
				+ "  \"lastName\": \"fathi59\",\r\n"
				+ "  \"password\": \"Ayesha@123fathi\",\r\n"
				+ "  \"phone\": 6379456372,\r\n"
				+ "  \"state\": \"Karnata\",\r\n"
				+ "  \"zoneId\": \"ALPHA\"\r\n"
				+ "}").contentType("application/json").
		when().post("https://www.shoppersstack.com/shopping/shoppers").
		then().statusCode(201).and().statusLine("HTTP/1.1 201 Created").extract().response();
	
	
	
	//json parsing
	
	
	System.out.println(resp.asPrettyString());//reponse body
	System.out.println( resp.statusCode());
	JsonPath jp = new JsonPath(resp.asPrettyString());
	String mess = jp.getString("message");
	System.out.println(mess);//message
	
	email = jp.getString("data.email");
	System.out.println(email);//json parsing email
	}
	
	@Test
	public void shopperlogin() {
		RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
				+ "  \"email\": \" "+email+"\",\r\n"
				+ "  \"password\": \"Ayesha@123fathi\",\r\n"
				+ "  \"role\": \"SHOPPER\"\r\n"
				+ "}").contentType("application/json").
	when().post("https://www.shoppersstack.com/shopping/users/login").then().statusCode(200).log().all();
	
	}
@Test
public void findshopperdataget() {
	RestAssured.given().relaxedHTTPSValidation().pathParam("shopperId", "225892").
	auth().oauth2("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJheWVzaGExMjU5NTdAZ21haWwuY29tIFNIT1BQRVIiLCJleHAiOjE3NDEzODQ1MDEsImlhdCI6MTc0MTM0ODUwMX0.r6iija2_Vquor2ayv-swOeAPK4GliKNlTPsMInbPXLs").
	when().get("https://www.shoppersstack.com/shopping/shoppers/{shopperId}").
	then().statusCode(200).log().all();
}
@Test
public void patch() {
	RestAssured.given().relaxedHTTPSValidation().pathParam("shopperId", "225892").
	auth().oauth2("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJheWVzaGExMjU5NTdAZ21haWwuY29tIFNIT1BQRVIiLCJleHAiOjE3NDEzODQ1MDEsImlhdCI6MTc0MTM0ODUwMX0.r6iija2_Vquor2ayv-swOeAPK4GliKNlTPsMInbPXLs").
	body("{\r\n"
			+ "  \"city\": \"Bangalore\",\r\n"
			+ "  \"country\": \"India\",\r\n"
			+ "  \"email\": \"ayesha125957@gmail.com\",\r\n"
			+ "  \"firstName\": \"Ayesha124\",\r\n"
			+ "  \"gender\": \"FEMALE\",\r\n"
			+ "  \"lastName\": \"fathi59\",\r\n"
			+ "  \"password\": \"Ayesha@123fathi\",\r\n"
			+ "  \"phone\": 6379456372,\r\n"
			+ "  \"state\": \"Karnata\",\r\n"
			+ "  \"zoneId\": \"ALPHA\"\r\n"
			+ "}").contentType("application/json").
	when().patch("https://www.shoppersstack.com/shopping/shoppers/{shopperId}").
	then().statusCode(200).log().all();
}
@Test
public void generateurlpass() {
	RestAssured.given().relaxedHTTPSValidation().headers("email", "ayesha125957@gmail.com","role","SHOPPER").
	when().post("https://www.shoppersstack.com/shopping/users/forgot-password").
	then().statusCode(200).log().all();
}
@Test
public void setpassword() 
{ 
	RestAssured.given().relaxedHTTPSValidation().header("password", "Ayesha@14322").queryParam("token", "Sd4iwwxbt0ztS64mASpOZqUfDHcPoJOOngi5z0ND7WEn7").
	when().post("https://www.shoppersstack.com/shopping/users/verify-account").
	then().statusCode(200).log().all();
}
//all assertion
@Test
public void createshopp() 
{
	String alphanumeric = RandomStringUtils.randomAlphanumeric(4);
	randomemail = "Ayesha"+alphanumeric+"@gmail.com";
	System.out.println(randomemail);
	RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
			+ "  \"city\": \"Bangalore\",\r\n"
			+ "  \"country\": \"India\",\r\n"
			+ "  \"email\": \""+ randomemail +"\",\r\n"
			+ "  \"firstName\": \"Ayesha12\",\r\n"
			+ "  \"gender\": \"FEMALE\",\r\n"
			+ "  \"lastName\": \"fathi59\",\r\n"
			+ "  \"password\": \"Ayesha@123fathi\",\r\n"
			+ "  \"phone\": 6379456372,\r\n"
			+ "  \"state\": \"Karnata\",\r\n"
			+ "  \"zoneId\": \"ALPHA\"\r\n"
			+ "}").contentType("application/json").
	when().post("https://www.shoppersstack.com/shopping/shoppers").
	then().statusCode(201).and().
	statusLine("HTTP/1.1 201 ").and().
	time(Matchers.lessThanOrEqualTo(5000l)).and().
	body("message", Matchers.equalTo("Created")).and().header("Server", Matchers.equalTo("nginx")).log().all();

	
}


}
