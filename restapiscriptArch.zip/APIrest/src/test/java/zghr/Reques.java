package zghr;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Reques 
{
	@Test
	public void post() {
		RestAssured.given().body("{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}").contentType("application/json").
		when().post("https://reqres.in/api/users").
		then().assertThat().statusCode(201).
		and().statusLine("HTTP/1.1 201 Created").
		and().time(Matchers.lessThanOrEqualTo(4000l)).
		and().body("name", Matchers.equalTo("morpheus")).
		and().header("Server", Matchers.equalTo("cloudflare")).log().all();
		
	}

}
