package zghr;

public class Deserilization_mainpojo_shop 
{
	private String statusCode;
	private String message;
	private Deserilization_Subpojo_data_shop  data;
	public String getStatusCode() {
		return statusCode;
	}
	public String getMessage() {
		return message;
	}
	public Deserilization_Subpojo_data_shop getData() {
		return data;
	}
}
