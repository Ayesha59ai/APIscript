package zghr;

public class Desele_pojo_req 
{
	private String name;
	private String job;
	private String id;
	private String createdAt;
	public String getName() {
		return name;
	}
	public String getJob() {
		return job;
	}
	public String getId() {
		return id;
	}
	public String getCreatedAt() {
		return createdAt;
	}

}
