package zghr;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Pojo_runner_req 
{
	
	
	@Test
	public void create() throws JsonProcessingException {
		Pojo_sere_req pj = new Pojo_sere_req();
		pj.setName("Ayehsa");
		pj.setJob("testing");
	
		ObjectMapper obj = new ObjectMapper();
		String jsonbody = obj.writeValueAsString(pj);
		
		Response respon = RestAssured.given().body(jsonbody).contentType("application/json").
		when().post("https://reqres.in/api/users").
		then().statusCode(201).and().statusLine("HTTP/1.1 201 Created").
		and().time(Matchers.lessThanOrEqualTo(4000l)).
		and().header("Server", Matchers.equalTo("cloudflare")).
		and().body("name", Matchers.equalTo("Ayehsa")).extract().response();
		
		//dese
		Desele_pojo_req des = respon.as(Desele_pojo_req .class);
		String id = des.getId();
		System.out.println(id);
		String nam = des.getName();
		System.out.println(nam);
		
		
	}

}
