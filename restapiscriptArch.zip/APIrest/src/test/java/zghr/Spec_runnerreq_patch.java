package zghr;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Spec_runnerreq_patch 
{
	@Test
	public void patch() 
	{
		Spec_Builer1 sb = new Spec_Builer1();
		RequestSpecification req = sb.request("https://reqres.in/", "{\r\n"
				+ "    \"name\": \"morbnmsgheus\",\r\n"
				+ "    \"job\": \"zion resident\"\r\n"
				+ "}", "application/json");
		
		ResponseSpecification resp = sb.response(200, "HTTP/1.1 200 OK");
		
		Response respon = RestAssured.given().spec(req).
				when().patch("api/users/2").then().spec(resp).extract().response();
		
		System.out.println(respon.asPrettyString());
		
		JsonPath jp=new JsonPath(respon.asPrettyString());
		String name = jp.getString("name");
		System.out.println(name);
		
	}

}
