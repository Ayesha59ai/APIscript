package zghr;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Spec_Builer1 
{
	@BeforeMethod
	public RequestSpecification request(String url,String body,String contenttype) 
	{
		RequestSpecBuilder rb = new RequestSpecBuilder();
		RequestSpecification req = rb.setBaseUri(url).setBody(body).setContentType(contenttype).build();
		return req;
		
		
	}
	@AfterMethod
	public ResponseSpecification response(int code,String line) {
		ResponseSpecBuilder rb = new ResponseSpecBuilder();
		ResponseSpecification res = rb.expectStatusCode(code).expectStatusLine(line).build();
		return res;
	}

}
