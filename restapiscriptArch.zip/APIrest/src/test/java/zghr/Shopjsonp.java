package zghr;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Shopjsonp 
{
	public String email;
	public String userid;
	public String token;
	@Test(priority=1)
	public void create() 
	{
		String randomnumber = RandomStringUtils.randomAlphanumeric(4);
		String remail = "Ayesha"+randomnumber+"@gmail.com";
		
		Response response = RestAssured.given().relaxedHTTPSValidation().
				body("{\r\n"
				+ "  \"city\": \"Bangalore\",\r\n"
				+ "  \"country\": \"India\",\r\n"
				+ "  \"email\": \""+remail+"\",\r\n"
				+ "  \"firstName\": \"Ayesha12\",\r\n"
				+ "  \"gender\": \"FEMALE\",\r\n"
				+ "  \"lastName\": \"fathi59\",\r\n"
				+ "  \"password\": \"Ayesha@123fathi\",\r\n"
				+ "  \"phone\": 6379456372,\r\n"
				+ "  \"state\": \"Karnata\",\r\n"
				+ "  \"zoneId\": \"ALPHA\"\r\n"
				+ "}").contentType("application/json").
		when().post(" https://www.shoppersstack.com/shopping/shoppers").
		then().assertThat().statusCode(201).
		statusLine("HTTP/1.1 201 ").extract().response();
		
		JsonPath jp=new JsonPath(response .asPrettyString());
		email = jp.getString("data.email");
		System.out.println(email);
		}
	@Test(priority=2)
	public void login() 
	{
		Response response = RestAssured.given().relaxedHTTPSValidation().body("{\r\n"
				+ "  \"email\": \""+email+"\",\r\n"
				+ "  \"password\": \"Ayesha@123fathi\",\r\n"
				+ "  \"role\": \"SHOPPER\"\r\n"
				+ "}").contentType("application/json").
		when().post(" https://www.shoppersstack.com/shopping/users/login").
		then().statusCode(200).statusLine("HTTP/1.1 200 ").extract().response();
		
		JsonPath jp=new JsonPath(response.asPrettyString());
		 token = jp.getString("data.jwtToken");
	  userid = jp.getString("data.userId");
		System.out.println(token);
		System.out.println(userid);
		
	}
	@Test(priority=3)
	public void getdata() 
	{
		RestAssured.given().relaxedHTTPSValidation().pathParam("shopperId", userid).auth().oauth2(token).
		when().get("https://www.shoppersstack.com/shopping/shoppers/{shopperId}").
		then().statusCode(200).log().all();
		
	}

}
