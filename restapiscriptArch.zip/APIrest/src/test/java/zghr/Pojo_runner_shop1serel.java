package zghr;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Pojo_runner_shop1serel 
{
	@Test
	public void createacct() throws JsonProcessingException {
		String randomnum = RandomStringUtils.randomAlphanumeric(4);
		String remail = "Ayesha"+randomnum+"@gmail.com";
		
	Pojo_Serelization1shop pj=new Pojo_Serelization1shop();
	pj.setCity("Bangalore");
	pj.setCountry("India");
	pj.setEmail(remail);
	pj.setFirstName("ayeshafathiii");
	pj.setGender("FEMALE");
	pj.setLastName("fathimaaa");
	pj.setPassword("Ayesha@36278");
	pj.setPhone("6654885779");
	pj.setState("Karnataka");
	pj.setZoneId("ALPHA");
	
	ObjectMapper obj=new ObjectMapper();
	String jsonbody = obj.writerWithDefaultPrettyPrinter().writeValueAsString(pj);
	
	//System.out.println(jsonbody);
	Response response = RestAssured.given().relaxedHTTPSValidation().
	body(jsonbody).contentType("application/json").
	when().post("https://www.shoppersstack.com/shopping/shoppers").
	then().statusCode(201).extract().response();
	System.out.println(response.asPrettyString());
	Deserilization_mainpojo_shop dese = response.as(Deserilization_mainpojo_shop.class);
	String msg = dese.getData().getCountry();
	System.out.println(msg);

}
}
