package zghr;

import java.io.IOException;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Spec_runnerReqr 
{
	@Test
	public void create() throws IOException 
	{
		Get_property gp = new Get_property();
	 String url = gp.property("basereqres");
	String endpoint = gp.property("endpoint");
		
	Spec_Builer1 sb = new Spec_Builer1();
	 RequestSpecification req = sb.request(url, "{\r\n"
			+ "    \"name\": \"morpheus\",\r\n"
			+ "    \"job\": \"leader\"\r\n"
			+ "}", "application/json");
	 ResponseSpecification res = sb.response(201, "HTTP/1.1 201 Created");
	 
	 RestAssured.given().spec(req).when().post(endpoint).
	 then().spec(res).log().all();
		
	}

}
