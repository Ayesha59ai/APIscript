package Spec_Builder;

import org.hamcrest.Matchers;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Spec 
{
	//if we use this we cant use in different diff request so 
	//we have create variable and method with parameter and we have to pass from runner script
	
	@BeforeMethod
	public RequestSpecification request() 
	{
		RequestSpecBuilder s=new RequestSpecBuilder();
		RequestSpecification req = s.setBaseUri("https://reqres.in/").setBody("{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}").setContentType("application/json").build();
		return req;
}
	@AfterMethod
	public ResponseSpecification response() {
		ResponseSpecBuilder s=new ResponseSpecBuilder();
		ResponseSpecification res = s.expectStatusCode(201).
		expectStatusLine("HTTP/1.1 201 Created").expectResponseTime(Matchers.lessThanOrEqualTo(4000l)).build();
		return res;
	}
}
