package POJO;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Reqres_runner 
{
	@Test
	public void Post() throws JsonProcessingException {
		Reqres_pojo_java rp = new Reqres_pojo_java();
		rp.setName("ayesha");
		rp.setJob("leader");
		//convert java to json
		ObjectMapper objt =new ObjectMapper();
		String  jsonbody = objt.writerWithDefaultPrettyPrinter().writeValueAsString(rp);
		//System.out.println(jsonbody);
		
		//pass
	Response response = RestAssured.given().body(jsonbody).contentType("application/json").
	when().post("https://reqres.in/api/users").then().statusCode(201).extract().response();
	System.out.println(response.asPrettyString());
	//System.out.println(response);
		
	}
	

}
