package POJO;

public class ShoppermainpojoD {
	
	 private int statusCode;
	 private String message;
	private ShopperSubPojo  data;
	public int getStatusCode() {
		return statusCode;
	}
	public String getMessage() {
		return message;
	}
	public ShopperSubPojo getData() {
		return data;
	}
	
}
