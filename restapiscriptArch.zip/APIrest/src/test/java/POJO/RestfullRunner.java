package POJO;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class RestfullRunner {
	@Test
	public void createbooking() throws JsonProcessingException {
		Restfull_pojo rp = new Restfull_pojo();
		rp.setFirstname("Ayesha");
		rp.setLastname("ayes");
		rp.setTotalprice(123);
		rp.setDepositpaid(true);

		Restbooking_pojo bp = new Restbooking_pojo();
		bp.setCheckin("2018-01-01");
		bp.setCheckout("2019-01-01");
		rp.setBookingdates(bp);
		
		rp.setAdditionalneeds("Breakfast");
		
		ObjectMapper obj =new ObjectMapper();
		String jsonbody = obj.writerWithDefaultPrettyPrinter().writeValueAsString(rp);
		System.out.println(jsonbody);
		
		Response respon = RestAssured .given().body(jsonbody).contentType("application/json").
		when().post("https://restful-booker.herokuapp.com/booking").then().statusCode(200).extract().response();
		System.out.println(respon.asPrettyString());
	
		
	}
}