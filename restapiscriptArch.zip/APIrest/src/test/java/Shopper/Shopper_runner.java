package Shopper;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Shopper_runner 
{
	@Test
	public void create() throws JsonProcessingException 
	{
		String random = RandomStringUtils.randomAlphabetic(5);
		String remail = "Ayesha"+random+"@gmail.com";
		Serelization_pojo sp = new Serelization_pojo ();
		sp.setCity("Bangalore");
		sp.setCountry("India");
		sp.setEmail(remail);
		sp.setFirstName("Ayeshua");
		sp.setGender("FEMALE");
		sp.setLastName("ayshu");
		sp.setPassword("Ayesha@5945");
		sp.setPhone(6436442989L);
		sp.setState("Karnataka");
		sp.setZoneId("ALPHA");
		//conver java
		ObjectMapper obj = new ObjectMapper();
	String jsonbody = obj.writerWithDefaultPrettyPrinter().writeValueAsString(sp);
	
	Response response = RestAssured.given().relaxedHTTPSValidation().body(jsonbody).contentType("application/json").
	when().post("https://www.shoppersstack.com/shopping/shoppers").then().extract().response();
	System.out.println(response.asPrettyString());
	
	//deserialization
Deserialization_main_pojo dese = response.as(Deserialization_main_pojo .class);
String emailid = dese.getData().getEmail();
System.out.println(emailid);
	
	
	
		
	}

}
