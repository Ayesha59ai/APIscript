package Shopper;

public class Deserialization_main_pojo 
{
	private String statusCode;	
	private String message;
	private Deserialization_data_pojo  data;
	public String getStatusCode() {
		return statusCode;
	}
	public String getMessage() {
		return message;
	}
	public Deserialization_data_pojo getData() {
		return data;
	}
}
