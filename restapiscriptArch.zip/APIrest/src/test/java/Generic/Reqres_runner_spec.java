package Generic;

import org.testng.annotations.Test;

import Spec_Builder.Spec_Builder1;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Reqres_runner_spec 
{
	@Test
	public void post() {
		Spec_Builder1 s=new Spec_Builder1();
	
		RequestSpecification req = s.request("https://reqres.in/", "{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}", "application/json");
		ResponseSpecification res = s.response(201, "HTTP/1.1 201 Created", 3000l);
		
		Response response = RestAssured.given().spec(req).
				when().post("api/users").then().spec(res).extract().response();
		System.out.println(response.asPrettyString());
	}
}