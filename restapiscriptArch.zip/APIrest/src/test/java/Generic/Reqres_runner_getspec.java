package Generic;

import org.testng.annotations.Test;

import Spec_Builder.Spec_Builder1;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Reqres_runner_getspec
{
	@Test
	public void getuser() {
		Spec_Builder1 s=new Spec_Builder1();
		RequestSpecification req = s.request2("https://reqres.in/api");
		ResponseSpecification res = s.response(200, "HTTP/1.1 200 OK", 4000l);
		
		RestAssured.given().spec(req).when().get("users/2").then().spec(res).log().all();
	}

}
